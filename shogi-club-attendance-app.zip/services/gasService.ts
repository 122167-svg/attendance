import type { AttendanceRecord } from '../types';

// Helper to get date in YYYY-MM-DD format, adjusted for timezone
const getLocalDate = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = (`0${d.getMonth() + 1}`).slice(-2);
    const day = (`0${d.getDate()}`).slice(-2);
    return `${year}-${month}-${day}`;
}

// Helper to get time in HH:mm:ss format
const getLocalTime = () => new Date().toLocaleTimeString('ja-JP', { hour12: false });


// This is a mock "database" for local development. It simulates the backend state.
const mockDatabase: { records: AttendanceRecord[] } = {
    records: [
        { name: "熱田 望", date: getLocalDate(), checkInTime: "09:01:15", checkOutTime: "15:30:00" },
        { name: "池田 大翔", date: getLocalDate(), checkInTime: "09:05:20", checkOutTime: null },
        { name: "岩間 悠希", date: "2024-07-20", checkInTime: "09:00:00", checkOutTime: "16:00:00" },
        { name: "白石 怜大", date: "2024-07-20", checkInTime: "09:10:00", checkOutTime: null },
    ]
};

// Simulate network latency for a more realistic development experience.
const MOCK_DELAY_MS = 500;

/**
 * Executes a Google Apps Script function and returns a Promise.
 * In a local dev environment, it provides mock data to allow for UI testing.
 * 
 * @param functionName The name of the function to call in your Apps Script project.
 * @param args The arguments to pass to the function.
 * @returns A Promise that resolves with the return value.
 */
export const gasRun = <T,>(functionName: string, ...args: any[]): Promise<T> => {
  if (typeof google === 'undefined' || !google?.script?.run) {
    console.warn(`[DEV MODE] Mocking gasRun call for function: "${functionName}"`);
    
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            switch (functionName) {
                case 'getTodayStatus': {
                    const today = getLocalDate();
                    const todaysRecords = mockDatabase.records.filter(r => r.date === today);
                    resolve(todaysRecords as T);
                    break;
                }

                case 'getAttendanceForDate': {
                    const [date] = args as [string];
                    if (!date) {
                        return reject(new Error("Mock Error: 'getAttendanceForDate' requires a date string."));
                    }
                    const recordsForDate = mockDatabase.records.filter(r => r.date === date);
                    resolve(recordsForDate as T);
                    break;
                }
                
                case 'recordAttendance': {
                    const [name, type] = args as [string, '出席' | '退室'];
                    if (!name || !type) {
                        return reject(new Error("Mock Error: 'recordAttendance' requires a name and a type."));
                    }
                    
                    const today = getLocalDate();
                    const now = getLocalTime();
                    let record = mockDatabase.records.find(r => r.name === name && r.date === today);

                    if (type === '出席') {
                        if (record) {
                            // Re-checking in on the same day resets the checkout time
                            record.checkInTime = now;
                            record.checkOutTime = null;
                        } else {
                            const newRecord: AttendanceRecord = { name, date: today, checkInTime: now, checkOutTime: null };
                            mockDatabase.records.push(newRecord);
                        }
                        const successMessage = `${name}さんを出席として記録しました。`;
                        resolve(successMessage as T);
                    } else { // '退室'
                        if (record && record.checkInTime) {
                            record.checkOutTime = now;
                            const successMessage = `${name}さんを退室として記録しました。`;
                            resolve(successMessage as T);
                        } else {
                            reject(new Error('エラー: 出席記録がないため退室できません。'));
                        }
                    }
                    break;
                }
                
                default:
                    return reject(new Error(`Mock Error: The function "${functionName}" is not implemented.`));
            }
        }, MOCK_DELAY_MS);
    });
  }

  // Production environment: Use the real google.script.run.
  return new Promise((resolve, reject) => {
    google.script.run
      .withSuccessHandler((result: T) => resolve(result))
      .withFailureHandler((error: Error) => reject(error))
      [functionName](...args);
  });
};